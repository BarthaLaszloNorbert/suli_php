<!DOCTYPE html>
<html lang="hu">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Ülésrend</title>
</head>
<body>
	<div id="claswsroom">
		<table>
			<tr id=firstColumn>
				<td>S. Balázs</td>
				<td>Halir Szabolcs</td>
				<td>Fehér László</td>
				<td colspan="1" class="emptyCell"></td>
				<td>Gulcsik Zoltán</td>
				<td>Harsányi Ferenc</td>
			</tr>
			<tr>
				<td>Kiss Márton</td>
				<td>Bartha László</td>
				<td>Krenner Dominik</td>
				<td colspan="1" class="emptyCell"></td>
				<td>Járfás Dániel</td>
				<td>Végh Szabolcs</td>
			</tr>
			<tr>
				<td>Bella Marcell</td>
				<td>Simon Attila</td>
				<td colspan="2" class="emptyCell"></td>
				<td>Hadnagy Márk</td>
				<td>Rácz Dávid</td>
			</tr>
			<tr>
				<td colspan="3" class="emptyCell"></td>
				<td >Bicsák József</td>
				<td colspan="1" class="emptyCell"></td>
				<td>Toperczer Márton</td>
			</tr>
			
		</table>
	</div>

<?php

?>
	
</body>
</html>
